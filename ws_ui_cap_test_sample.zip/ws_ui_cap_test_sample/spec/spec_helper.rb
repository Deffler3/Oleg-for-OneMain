require 'capybara/rspec'
require 'rubygems'
require 'webdrivers'
require 'capybara/dsl'
#require 'capybara-screenshot/rspec'
require 'active_support/all'
require 'pry'
require './spec/config/get_config'
require_relative '../lib/utils/actions'
require_relative '../lib/utils/actions'
require 'rspec/retry'
require 'pathname'


helpers_path = File.join(Dir.pwd, 'spec', 'features', 'lib')

[File.join(helpers_path, '*helper_spec.rb')].each do |regex_files| # regex for all the helpers files (ending with "_helper_spec.rb")
  Dir.glob(regex_files).each { |f| require f }
end


# Test configurations
configurations = GetConfig.new
is_local = configurations.is_local
browser = configurations.get_browser

###
Capybara.default_driver = :selenium
Capybara.app_host = configurations.get_url
Capybara.run_server = false
Capybara.default_max_wait_time = 25


class String
  def to_b
    to_s.match(/(true|yes|y|1)/i) != nil
  end
end

RSpec.configure do |config|

  if is_local.to_b

    case browser

    when 'chrome'
      puts "[MESSAGE-ENV] Selected local:#{browser}"

      Capybara.register_driver :selenium do |app|
        Capybara::Selenium::Driver.new(app, :browser => :chrome)
        #Capybara.javascript_driver = :chrome
      end

    when 'firefox'

      Capybara.register_driver :selenium do |app|
        profile = Selenium::WebDriver::Firefox::Profile.new
        profile['dom.max_script_run_time'] = '77'
        profile.secure_ssl = false
        profile.assume_untrusted_certificate_issuer = false
        Capybara::Selenium::Driver.new(app, :browser => :firefox, profile: profile)
      end

    else
      puts "[MESSAGE-ENV] Selected local:#{browser}"

      Capybara.register_driver :selenium do |app|
        Capybara::Selenium::Driver.new(app, :browser => :chrome)
      end

    end

  else
    puts "Going remote with #{browser}"
    # Remote here

  end

  # show retry status in spec process
  config.verbose_retry = true
  # show exception that triggers a retry if verbose_retry is set to true
  config.display_try_failure_messages = true

  # run retry only on features
  config.around :each, :js do |ex|
    ex.run_with_retry retry: 2
  end
end






















