require 'yaml'
class GetConfig

  @yaml = nil
  attr_accessor :environment, :is_local, :browser, :os, :hub

  # #
  # export QA_WEB_HOST = 
  # export LOCAL = false
  # export BROWSER = chrome
  # export OS = mac
  # export SELENIUM_HUB =hub1

  #####local automation

  def initialize(params = {})

    @environment = params.fetch(:environment, ENV["QA_WEB_HOST"] ||= 'sonoma')  ### host env
    @is_local = params.fetch(:is_local, ENV["LOCAL"] ||= 'true')             ### local true or false
    @browser = params.fetch(:browser, ENV["BROWSER"] ||= '')           ### firefox, safari
    @os = params.fetch(:os, ENV["OS"] ||= 'mac')                             ### mac or win
    @hub = params.fetch(:hub,ENV["SELENIUM_HUB"] ||= "hub1")                 ### hub1, hub6


    ## initiates variables to manipulate in upcoming loop
    config = YAML.load_file('./spec/config/config.yml')
    env_data              = config['data'][@environment] || {}

    ## array of variable names to define keys in $ev hash
    env_variables = %w(email)
    $ev = {}

    ## loop to set $ev key and value that will default if not present in environment
    env_variables.each do |var|
      if env_data.key?(var)
        $ev[var] = config['data'][@environment][var]
      else
        $ev[var] = config['data']['default'][var]
      end
    end
  end

  def get_os
    get_network('os', @os)
  end

  def get_url
    url = get_environment('url')
  end

  def get_browser
    get_network('browser', @browser)
  end

  def is_local
    @is_local
  end

  def selenium_hub
    get_network('selenium_hubs', @hub)
  end

  private

  def yaml
    if @yaml.nil?
      @yaml = YAML.load_file('./spec/config/config.yml')
    end
    @yaml
  end

  def get_environment(param)
    final_result = ''
    results = yaml['environment']["config"]
    results.each do |data_value|
      if data_value["id"] == @environment
        final_result = data_value[param]
        break
      end
    end
    final_result
  end

  def get_network(id, param)
    final_result = ''
    results = yaml['network']['config']
    results.each do |data_value|
      if data_value["id"] == id
        final_result = data_value[param]
        break
      end
    end
    return final_result
  end

end
