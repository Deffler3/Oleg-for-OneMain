require './spec/spec_helper'
require_relative '../../lib/pages/sonoma_main'
require_relative '../../lib/utils/actions'

feature 'Williams - Sonoma' do

  before(:each) do
    # visit sonoma page
    visit '/'
    browser_maximize
    delete_all_cookies
    check_remove_advertisement
  end


  it 'User should be able to go to a product page and add the product to the cart' do

    find("a", :text => "COOKS' TOOLS").hover
    find('a', :text => "Salt & Pepper Mills", wait: 10).click
    find('a', :text => "Peugeot Fidji Salt & Pepper Mills, Olivewood").click
    check_remove_advertisement
    find('a', :text => "Mill Set", wait: 10).click
    sleep(4)
    # Product page shows "Add to cart” button
    expect(page).to have_xpath '//*[@id="primaryGroup_addToCart_0"]/span'
    find("#primaryGroup_addToCart_0").click
    # When click on "Add to cart” button, add to cart overlay appears
    expect(page).to have_content "You've just added the following to your basket"
    # # Checkout button is on the add to cart overlay
    expect(page).to have_xpath ' //*[@id="anchor-btn-checkout"]'
    find("#anchor-btn-checkout").click
    # When click on "Checkout" button then shopping cart page is shown ● The product you added to cart should be on shopping cart page
    expect(page).to have_content "Peugeot Fidji Salt and Pepper Mill Set"
  end


  it "user should be able to search for a product and open it's quick look overlay" do
    fill_in 'search-field', with: 'Fry Pan Set'
    sleep 3
    product_description = all('a[class*="product-name"]')[0].text
    puts product_description
    #Capybara.pry
    expect(product_description.include? 'Fry Pan').to be_truthy
  end

  it "user should be able to see the exact same clicked product on the quick look overlay" do
    fill_in 'search-field', with: 'Fry Pan Set'
    sleep 3
    product_description = all('a[class*="product-name"]')[0].text
    puts product_description
    #Capybara.pry
    expect(product_description.include? 'Fry Pan').to be_truthy
    all('a[class*="product-name"]')[0].click
    expect(page).to have_content product_description
  end

end