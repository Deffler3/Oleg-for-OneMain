require_relative '../../spec/spec_helper'

def check_remove_advertisement

  #attentive_creative iframe
  puts "Checking advertisement"
  #Capybara.pry
  if page.has_css?('iframe[id="attentive_creative"]', :wait => 5)
    switch_to_iframe("attentive_creative")
    puts '[INFO] Going to remove Advertisement popup'
    click_button('Close')
    switch_to_frame :top
    sleep 3
  end
end