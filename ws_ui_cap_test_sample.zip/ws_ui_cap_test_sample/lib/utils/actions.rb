require_relative '../../spec/spec_helper.rb'

def get_current_url
  page.current_url
end

def delete_all_cookies
  Capybara.current_session.driver.browser.manage.delete_all_cookies
end


def browser_back
  sleep 2
  page.evaluate_script('window.history.back()')
  sleep 2
end

def browser_forward
  page.evaluate_script('window.history.forward()')
end

def click_image_by_alt(alt)
  find("img[alt='#{alt}']").click
end


def click_image_by_partial_alt(alt)
  find("img[alt*='#{alt}']").click
end


def browser_maximize(bigger_browser_window = true)
  Capybara.current_session.driver.browser.manage.window.maximize
  if bigger_browser_window
    page.driver.browser.manage.window.resize_to('1920', '1080')
  end
  sleep 1
end

def click_similar_link_by_index_partial(linkNamePartial, index)
  all(:link, linkNamePartial, exact: false)[index].click
end

def click_similar_link_by_index(linkName, index)
  all(:link, linkName, wait: 20)[index].click
end

def click_similar_button_by_index(buttonName, index)
  all(:button, buttonName, wait: 20)[index].click
end

def click_similar_link_by_last(linkName)
  all(:link, linkName).last
end

def click_similar_button_by_last(buttonId)
  all(:button, buttonId).last.click
end

def select_from_dropdown(option, class_name_id)
  select(option, :from => class_name_id)
end

def close_and_switch_window
  # page.driver.browser.close
  session.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
end

def click_by_id(id)
  find("##{id}").click
end

def send_by_id(id, text)
  find("#{id}").click.send_keys(text)
end


def switch_to_iframe(id)
  Capybara.current_session.driver.browser.switch_to.frame(id)
end